export interface Todo {
    id: number;
    name: string;
    description: string;
    repeating: boolean;
    isDone: boolean;
}